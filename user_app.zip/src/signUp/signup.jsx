import React, { Component } from "react";
// import "./Signup.css";
import styled from 'styled-components';
import { CognitoUserPool, CognitoUserAttribute, CognitoUser, AuthenticationDetails } from 'amazon-cognito-identity-js';
import userPool from '../config'
import { Redirect } from 'react-router'
import history from '../history';


export default class Signup extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      email: "",
      password: "",
      confirmPassword: "",
      firstName: "",
      lastName:"",
      country: "",
      userName:"",
      signUpFlag:true,
      lEmail: "",
      lPassword: "",
    };
  }

  validateForm = () => {
    return (
      this.state.email.length > 0 &&
      this.state.password.length > 0 &&
      this.state.password === this.state.confirmPassword
    );
  }

  LoginvalidateForm = () => {
    return (
      this.state.email.length > 0 &&
      this.state.password.length > 0
    );
  }

  clearValues = () => {
    this.setState({
      email: "",
      password: "",
      confirmPassword: "",
      firstName: "",
      lastName:"",
      country: "",
      userName:"",
      lEmail: "",
      lPassword: "",
    });
  }

  switchAction = () => {
    this.setState({
      signUpFlag: !this.state.signUpFlag
    });
  }

  handleChange = event => {
    this.setState({
      [event.target.name]: event.target.value
    });
  }

  handleSubmit = event => {
    event.preventDefault();
    // this.setState({ isLoading: true });
    // this.setState({ newUser: "test" });
    // this.setState({ isLoading: false });
    const {email, password,  firstName, lastName, country, userName} =this.state;

//     fetch(`/api/usersignup?name=${encodeURIComponent(this.state)}`)
//     .then(response => response.json())
//     .then(state => {
//       console.log("============================",state)
//       this.setState(state)});
// return;
    const attributeList = [];
    const dataEmail = {
        Name : 'email',
        Value : email // your email here
    };
    const dataPersonalName = {
        Name : 'name',
        Value : userName 
    };
    // const dataFirstName = {
    //   // Name : 'firstName',
    //   Name : 'middle name',
    //   Value : firstName 
    // };
    // const dataLastName = {
    //   // Name : 'lastName',
    //   Name : 'family name',
    //   Value : lastName 
    // };
    // const dataCountryName = {
    //   // Name : 'country',
    //   Name : 'address',
    //   Value : country 
    // };
    const attributeEmail = new CognitoUserAttribute(dataEmail);
    const attributePersonalName = new CognitoUserAttribute(dataPersonalName);
    // const attributeFirstName = new CognitoUserAttribute(dataFirstName);
    // const attributeLastNameName = new CognitoUserAttribute(dataLastName);
    // const attributeCountryName = new CognitoUserAttribute(dataCountryName);   

    attributeList.push(attributeEmail);
    attributeList.push(attributePersonalName);
    // attributeList.push(attributeFirstName);
    // attributeList.push(attributeLastNameName);
    // attributeList.push(attributeCountryName);
  
    let cognitoUser;
    userPool.signUp(email, password, attributeList, null, (err, result)=>{
        if (err) {
            console.log("error----",err);
            return;
        }
        cognitoUser = result.user;
        this.switchAction();
        this.clearValues()
        console.log('user name is ' + cognitoUser.getUsername());
    });
  }
  userProfile = () => {
    alert("sdf")
    return <Redirect
    to={{
      pathname: "/userProfile",
    }}
    />
    // return( <Redirect to="/userProfile" />)
    // history.push({
    //   pathname:'/userProfile'
    // })
    // this.context.router.history.push('/userProfile')

    // <Link to="/courses" replace />
  }

  handleLogin = event => {
    event.preventDefault();
    const {lEmail, lPassword} =this.state;

    const authenticationData = {
      Username : lEmail,
      Password : lPassword,
    };

    const authenticationDetails = new AuthenticationDetails(authenticationData);
    var userData = {
        Username : lEmail,
        Pool : userPool
    };

    var cognitoUser = new CognitoUser(userData);
    cognitoUser.authenticateUser(authenticationDetails, {
        onSuccess:  (result) =>{
            console.log('access token + ' + result.getAccessToken().getJwtToken());
            
            cognitoUser.getUserAttributes((err, result)=> {
              if (err) {
                  alert(err);
                  return;
              }
              console.log('result token + ' + result);
            this.clearValues();
              for (let i = 0; i < result.length; i++) {
                  console.log('attribute ' + result[i].getName() + ' has value ' + result[i].getValue());
                  
              }
              const emailVerification = result.filter(result=>result.getName()==="email_verified")
              emailVerification.length > 0 && this.userProfile()
          });
            return(<Redirect to="/userProfile" />)
        },

        onFailure: (err) =>{
            console.log('error ' + err);
        },
    });
    // return( <Redirect to="/userProfile" />)
  //   return <Redirect
  // to={{
  //   pathname: "/userProfile",
  // }}
// /> 
    
  }

  signupForm = () => {
    return (
      <Form onSubmit={this.handleSubmit}>
        <h1>Signup Form</h1>
        <FormGroup className="userNAme">
          <label>User Name:</label>
          <input
            value={this.state.userName}
            onChange={this.handleChange}
            name="userName"
            type="text"
          />
        </FormGroup>
        <FormGroup className="email" >
          <ControlLabel>Email:</ControlLabel>
          <input
            autoFocus
            type="email"
            name="email"
            value={this.state.email}
            onChange={this.handleChange}
          />
        </FormGroup>
        <FormGroup className="firstName">
          <label>First Name:</label>
          <input
            value={this.state.firstName}
            onChange={this.handleChange}
            type="text"
            name="firstName"
          />
        </FormGroup>
        <FormGroup className="lastName">
          <ControlLabel>Last Name:</ControlLabel>
          <input
            value={this.state.lastName}
            onChange={this.handleChange}
            type="text"
            name="lastName"
          />
        </FormGroup>
        <FormGroup className="password">
          <ControlLabel>Password:</ControlLabel>
          <input
            value={this.state.password}
            onChange={this.handleChange}
            type="password"
            name="password"
          />
        </FormGroup>
        <FormGroup className="confirmPassword">
          <ControlLabel>Confirm Password:</ControlLabel>
          <input
            value={this.state.confirmPassword}
            onChange={this.handleChange}
            type="password"
            name="confirmPassword"
          />
        </FormGroup>
        <FormGroup className="country">
          <ControlLabel>country:</ControlLabel>
          <input
            value={this.state.country}
            onChange={this.handleChange}
            type="text"
            name="country"
          />
        </FormGroup>
        <LoaderButton
          block
          disabled={!this.validateForm()}
          type="submit"
          isLoading={this.state.isLoading}
          text="Signup"
          loadingText="Signing up…"
        />
        <SwitchWraper>
          <ControlLabel>create new user:</ControlLabel>
          <SwitchButton
            onClick={this.switchAction}
          > 
            Login
          </SwitchButton>
        </SwitchWraper>
      </Form>
    );
  }

  loginForm = () => {
    return (
      <Form onSubmit={this.handleLogin}>
        <h1>Login Form</h1>
        <FormGroup className="email" >
          <ControlLabel>Email:</ControlLabel>
          <input
            autoFocus
            type="email"
            name="lEmail"
            value={this.state.lEmail}
            onChange={this.handleChange}
          />
        </FormGroup>
        <FormGroup className="password">
          <ControlLabel>Password:</ControlLabel>
          <input
            value={this.state.lPassword}
            onChange={this.handleChange}
            type="password"
            name="lPassword"
          />
        </FormGroup>
        <LoaderButton
          block
          // disabled={!this.LoginvalidateForm()}
          type="submit"
          isLoading={this.state.isLoading}
          text="Login"
          loadingText="Login…"
        />
        <SwitchWraper>
          <ControlLabel>already have an account:</ControlLabel>
          <SwitchButton
            onClick={this.switchAction}
          >
            SignUp
          </SwitchButton>
        </SwitchWraper>
      </Form>
    )
  }

  render() {
    return (
      <div >
        {this.state.signUpFlag 
          ? this.signupForm()
          : this.loginForm()
        }
      </div>
    );
  }
}

const FormGroup = styled.div`
  display: flex;
  justify-content: space-between;
  margin: 10px;
`;

const LoaderButton = styled.input`

`;
const ControlLabel = styled.label`
padding-right: 10px;
`;

const Form = styled.form`
  border: solid 1px #ffff;
  padding: 20px;
`;

const SwitchWraper =styled.div`
  display: flex;
  justify-content: flex-end;
  padding: 10px;
`;
const SwitchButton = styled.button`
  background-color: cadetblue;
  border: cadetblue;
  border-radius: 10px;
`;