import React, {Component} from 'react'
import { Switch, Route } from 'react-router-dom'
import App from './App';
import UserProfile from './profile/userProfile'

class Routes extends Component {
    constructor(props) {
      super(props);
      this.state = {
        
      };
    }
    render(){
        return (
            <main>
              <Switch>
                <Route exact path='/' component={App}/>
                <Route path='/userProfile' component={UserProfile}/>
              </Switch>
            </main>
          );
    }

}

export default Routes;