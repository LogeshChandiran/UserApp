import React, { Component } from "react";
import styled from 'styled-components';
// import { CognitoUserPool, CognitoUserAttribute, CognitoUser, AuthenticationDetails } from 'amazon-cognito-identity-js';
// import userPool from '../config';

export default class UserProfile extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: "",
      firstName: "",
      lastName:"",
      country: "",
      userName:"",
    };
  }

  
  render() {
    return (
      <Wraper >
        <h1>Hello Logged In Username,</h1>
        <h3>Here your Profile</h3>
        <FormGroup>
            <ControlLabel>First Name : </ControlLabel>
            <ControlLabel>Logesh </ControlLabel>
        </FormGroup>
        <FormGroup>
            <ControlLabel>Last Name : </ControlLabel>
            <ControlLabel>c </ControlLabel>
        </FormGroup>
        <FormGroup>
            <ControlLabel>EmailId : </ControlLabel>
            <ControlLabel>ac.logesh@gmail.com </ControlLabel>
        </FormGroup>
        <FormGroup>
            <ControlLabel>Country : </ControlLabel>
            <ControlLabel>India  </ControlLabel>
        </FormGroup>

      </Wraper>
    );
  }
}

const FormGroup = styled.div`
  display: flex;
  justify-content: space-between;
  margin: 10px 20%;
`;

const ControlLabel = styled.label`
padding-right: 10px;
`;

const Wraper = styled.div`
  border: solid 1px black;
  margin:10px 35%;
  padding:20px;
`;